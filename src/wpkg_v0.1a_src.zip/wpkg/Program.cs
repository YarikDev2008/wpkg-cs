﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;

namespace wpkg
{
    class Program
    {
        static string s;
        static string m;
        static string fase;
        static void Main(string[] args)
        {
            Process proc = new Process();
            Process proc1 = new Process();
            Process proc2 = new Process();
            Process proc3 = new Process();
            if (args.Length >= 1)
            {
                if (args[0] == "/install")
                {
                    if (args.Length == 2)
                    {

                        Console.WriteLine("[1/3]: Downloading a " + args[1]);
                        proc.StartInfo.FileName = "C://wpkg//bin//curl.exe";
                        proc.StartInfo.Arguments = "-LOk https://github.com/YarikDev2008/wpkg-cs/raw/491e34a8394c7b3381f1bfffd21f77e27d0ce38a/pack/" + args[1] + ".7z -o C://wpkg//tmp//" + args[1] + ".7z";
                        proc.Start();
                        proc.WaitForExit();
                        Console.WriteLine("[2/3]: Unpacking a " + args[1]);
                        proc1.StartInfo.FileName = "C://wpkg//bin//7z.exe";
                        proc1.StartInfo.Arguments = "x C://wpkg//" + args[1] + ".7z -oC://wpkg//tmp//" + args[1];
                        proc1.Start();
                        proc1.WaitForExit();
                        FileStream mainfile = new FileStream("C://wpkg//prog//" + args[1] + "//type", FileMode.Open);
                        StreamReader mainread = new StreamReader(mainfile);
                        string cfgFileInside = mainread.ReadToEnd();
                        mainfile.Close();
                        if (cfgFileInside.StartsWith("compiled"))
                        {
                            Console.WriteLine("[3/3]: Installing a " + args[1]);
                            Process.Start("mkdir", "C://wpkg//prog//" + args[1]);
                            s = File.ReadAllText("C://wpkg//prog//1.txt");
                            m = s.Replace("e", args[1]);
                            File.WriteAllText("C://wpkg//tmp//1.bat", m);
                            Process.Start("C://wpkg//tmp//1.bat");
                            Console.WriteLine("Installed!");
                            Console.WriteLine("Startup a app? [Y or N]");
                            fase = Console.ReadLine();
                            if (fase == "y")
                            {
                                Process.Start("C://wpkg//prog//" + args[1] + "//start.bat");
                            }
                        }
                        else
                        {
                            Console.WriteLine("This package is not compiled!");
                            Console.WriteLine("Use wpkg /compile " + args[1]);
                        }
                    }
                    else if (args.Length == 1)
                    {
                        Console.WriteLine("Type a package name");
                    }
                }
                else if (args[0] == "/delete")
                {
                    if (args.Length == 2)
                    {
                        Console.WriteLine("[1/2] Deleting Package");
                        proc2.StartInfo.FileName = "del";
                        proc2.StartInfo.Arguments = "C://wpkg//prog//" + args[1] + "//* /s /q";
                        proc2.Start();
                        proc2.WaitForExit();
                        Console.WriteLine("[2/2] Ending");
                        proc2.StartInfo.FileName = "rd";
                        proc2.StartInfo.Arguments = "C://wpkg//prog//" + args[1] + " /s /q";
                        proc2.Start();
                        proc2.WaitForExit();
                    }
                    else if (args.Length == 1)
                    {
                        Console.WriteLine("Type a package name");
                    }
                }
            }
            else if(args.Length == 0)
            {
                Console.WriteLine("Windows Package Manager (wpkg) by YarikDev");
                Console.WriteLine("Arguments:");
                Console.WriteLine("/install *pkgname* - installes a *pkgname* (program)");
                Console.WriteLine("/delete *pkgname* - deletes a *pkgname* (program)");
                Console.WriteLine("/compile *pkgname* - compiles a *pkgname* (program)");
            }
        }
    }
}
